document.addEventListener('DOMContentLoaded', () => {
    const token = localStorage.getItem('authToken');

    if (!token) {
        window.location.href = 'auth.html'; // Redirect to login if not logged in
        return; // Stop script execution
    }

    // Decode token to get username for display
    try {
        const payload = JSON.parse(atob(token.split('.')[1]));
        document.getElementById('welcome-user').textContent = `Selamat datang, ${payload.username}!`;
    } catch (e) {
        console.error("Invalid token:", e);
        localStorage.removeItem('authToken');
        window.location.href = 'auth.html';
    }


    // Handle Logout
    document.getElementById('logout-btn').addEventListener('click', () => {
        localStorage.removeItem('authToken');
        window.location.href = 'auth.html';
    });

    // Function to show a specific section
    function showSection(sectionId) {
        document.getElementById('reservation-form-section').classList.add('d-none');
        document.getElementById('queue-status-section').classList.add('d-none');
        document.getElementById(sectionId).classList.remove('d-none');
    }

    // Initially show the reservation form
    showSection('reservation-form-section');


    // Handle Reservation Form Submission
    document.getElementById('reservation-form').addEventListener('submit', async (e) => {
        e.preventDefault();

        const reservationData = {
            nama: document.getElementById('fullName').value,
            email: document.getElementById('email').value,
            telepon: document.getElementById('phoneNumber').value,
            layanan: document.getElementById('serviceType').value,
            tanggal: document.getElementById('reservationDate').value,
            waktu: document.getElementById('reservationTime').value,
        };

        try {
            const response = await fetch('http://localhost:3000/reservasi', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify(reservationData)
            });

            const result = await response.json();

            if (response.ok) {
                // Update success modal with actual reservation ID
                document.getElementById('modal-queue-number').textContent = result.reservationId;

                // Show success modal
                const successModal = new bootstrap.Modal(document.getElementById('successModal'));
                successModal.show();

                // Clear form
                document.getElementById('reservation-form').reset();

                // After modal closes, display queue status (optional, can be removed if not needed)
                document.getElementById('successModal').addEventListener('hidden.bs.modal', () => {
                    // You might want to fetch the full reservation details again to display properly
                    displayQueueStatus({
                        ...reservationData, // Use current form data for display
                        queueNumber: result.reservationId // Use the actual ID from server
                    });
                    showSection('queue-status-section');
                });

            } else {
                alert(result.message || 'Reservation failed.');
            }

        } catch (error) {
            console.error('Error during reservation:', error);
            alert('An error occurred. Please try again.');
        }
    });

    // Function to display queue status (re-using the existing one)
    function displayQueueStatus(reservationData) {
        document.getElementById('display-queue-number').textContent = reservationData.queueNumber;
        document.getElementById('status-fullName').textContent = reservationData.nama;
        document.getElementById('status-serviceType').textContent = reservationData.layanan;
        document.getElementById('status-reservationDate').textContent = reservationData.tanggal;
        document.getElementById('status-reservationTime').textContent = reservationData.waktu;
        // You may need to add branchLocation if it's part of the data being sent or retrieved
        // document.getElementById('status-branchLocation').textContent = reservationData.branchLocation;
        document.getElementById('estimated-wait-time').textContent = `~ ${Math.floor(Math.random() * 15) + 5} menit`;
    }

    // Handle "Reservasi Baru" button click
    document.getElementById('new-reservation-btn').addEventListener('click', () => {
        showSection('reservation-form-section');
    });
});
