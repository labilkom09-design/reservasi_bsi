// Function to switch between login and register cards
function showCard(cardId) {
    const loginCard = document.getElementById('login-card');
    const registerCard = document.getElementById('register-card');

    if (cardId === 'register-card') {
        loginCard.classList.add('d-none');
        registerCard.classList.remove('d-none');
    } else {
        registerCard.classList.add('d-none');
        loginCard.classList.remove('d-none');
    }
}

// Event Listeners for switching cards
document.getElementById('show-register').addEventListener('click', (e) => {
    e.preventDefault();
    showCard('register-card');
});

document.getElementById('show-login').addEventListener('click', (e) => {
    e.preventDefault();
    showCard('login-card');
});

// User registration
document.getElementById('register-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const username = document.getElementById('register-username').value;
    const password = document.getElementById('register-password').value;

    if (!username || !password) {
        alert('Username and password are required!');
        return;
    }

    try {
        const response = await fetch('http://localhost:3000/register', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ username, password }),
        });

        const result = await response.json();

        if (response.ok) {
            alert('Registration successful! Please login.');
            showCard('login-card');
            document.getElementById('register-form').reset();
        } else {
            alert(result.message || 'Registration failed.');
        }
    } catch (error) {
        console.error('Error during registration:', error);
        alert('An error occurred. Please try again.');
    }
});

// User login
document.getElementById('login-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const username = document.getElementById('login-username').value;
    const password = document.getElementById('login-password').value;

    if (!username || !password) {
        alert('Username and password are required!');
        return;
    }

    try {
        const response = await fetch('http://localhost:3000/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ username, password }),
        });

        const result = await response.json();

        if (response.ok) {
            // Store the token and redirect
            localStorage.setItem('authToken', result.token);
            window.location.href = 'index.html';
        } else {
            alert(result.message || 'Invalid username or password!');
        }
    } catch (error) {
        console.error('Error during login:', error);
        alert('An error occurred. Please try again.');
    }
});