document.addEventListener('DOMContentLoaded', async () => {
    const token = localStorage.getItem('authToken');
    const navUserActions = document.getElementById('nav-user-actions');
    const mainActionBtn = document.getElementById('main-action-btn');

    if (token) {
        // Simple decode to get username without verifying signature (for display only)
        // Note: For security, sensitive data should not be stored in JWT payload
        try {
            const payload = JSON.parse(atob(token.split('.')[1]));
            navUserActions.innerHTML = `
                <span class="navbar-text me-3">Welcome, ${payload.username}</span>
                <button id="logout-btn" class="btn btn-outline-danger">Logout</button>
            `;
            mainActionBtn.textContent = 'Buat Reservasi';
            mainActionBtn.href = 'reservasi.html';

            document.getElementById('logout-btn').addEventListener('click', () => {
                localStorage.removeItem('authToken');
                window.location.href = 'index.html';
            });
        } catch (e) {
            console.error('Invalid token:', e);
            // If token is invalid, clear it
            localStorage.removeItem('authToken');
        }
    } else {
        navUserActions.innerHTML = '<a href="auth.html" class="btn btn-outline-primary">Login / Register</a>';
        mainActionBtn.textContent = 'Ambil Tiket Antrian';
        mainActionBtn.href = 'auth.html';
    }
});