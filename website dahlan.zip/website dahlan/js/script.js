// Function to show a specific section and hide others
function showSection(sectionId) {
    const sections = ['hero-section', 'steps-section', 'reservation-form-section'];
    sections.forEach(id => {
        const section = document.getElementById(id);
        if (section) {
            section.classList.add('d-none');
        }
    });
    const targetSection = document.getElementById(sectionId);
    if (targetSection) {
        targetSection.classList.remove('d-none');
    }
}

// Handle "Ambil Tiket Antrian" button click
document.querySelector('.hero-section .btn-primary').addEventListener('click', (e) => {
    e.preventDefault();
    showSection('reservation-form-section');
});

// Handle "Kembali" button click on reservation form
document.getElementById('back-to-home').addEventListener('click', (e) => {
    e.preventDefault();
    showSection('hero-section');
    document.getElementById('reservation-form').reset(); // Clear form on going back
});

// Handle reservation form submission
document.getElementById('reservation-form').addEventListener('submit', (e) => {
    e.preventDefault();

    const formData = {
        fullName: document.getElementById('fullName').value,
        email: document.getElementById('email').value,
        phoneNumber: document.getElementById('phoneNumber').value,
        serviceType: document.getElementById('serviceType').value,
        reservationDate: document.getElementById('reservationDate').value,
        reservationTime: document.getElementById('reservationTime').value,
        branchLocation: document.getElementById('branchLocation').value,
    };

    // Simulate saving to local storage (in a real app, this would go to a backend)
    let reservations = JSON.parse(localStorage.getItem('bsiReservations')) || [];
    reservations.push(formData);
    localStorage.setItem('bsiReservations', JSON.stringify(reservations));

    // Show success modal
    const successModal = new bootstrap.Modal(document.getElementById('successModal'));
    successModal.show();

    // Clear form after submission
    document.getElementById('reservation-form').reset();

    // Optionally, go back to home after modal is closed (or a few seconds)
    document.getElementById('successModal').addEventListener('hidden.bs.modal', () => {
        showSection('hero-section');
    });
});

// Initial display: Show hero and steps section
document.addEventListener('DOMContentLoaded', () => {
    showSection('hero-section'); // Ensure hero and steps are visible initially
    const stepsSection = document.getElementById('steps-section');
    if (stepsSection) {
        stepsSection.classList.remove('d-none');
    }
});
