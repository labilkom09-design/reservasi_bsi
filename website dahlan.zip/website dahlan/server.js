const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const cors = require('cors');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

const app = express();
const port = 3000;
const saltRounds = 10;
const JWT_SECRET = 'your_super_secret_key'; // Ganti dengan secret key yang lebih aman di production

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(__dirname));


// Koneksi Database MySQL
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '', // Kosongkan jika tidak ada password
    database: 'reservasi_db'
});

db.connect(err => {
    if (err) {
        console.error('Error connecting to database:', err);
        return;
    }
    console.log('Connected to MySQL database...');
});

// Endpoint untuk menyajikan halaman utama
app.get('/', (req, res) => {
    res.sendFile('index.html', { root: __dirname });
});

// Endpoint untuk Registrasi
app.post('/register', (req, res) => {
    const { username, password } = req.body;

    if (!username || !password) {
        return res.status(400).json({ message: 'Username and password are required' });
    }

    bcrypt.hash(password, saltRounds, (err, hash) => {
        if (err) {
            return res.status(500).json({ message: 'Error hashing password', error: err });
        }

        const sql = 'INSERT INTO users (username, password) VALUES (?, ?)';
        db.query(sql, [username, hash], (err, result) => {
            if (err) {
                if (err.code === 'ER_DUP_ENTRY') {
                    return res.status(409).json({ message: 'Username already exists' });
                }
                return res.status(500).json({ message: 'Database error', error: err });
            }
            res.status(201).json({ message: 'User registered successfully' });
        });
    });
});

// Endpoint untuk Login
app.post('/login', (req, res) => {
    const { username, password } = req.body;

    if (!username || !password) {
        return res.status(400).json({ message: 'Username and password are required' });
    }

    const sql = 'SELECT * FROM users WHERE username = ?';
    db.query(sql, [username], (err, results) => {
        if (err) {
            return res.status(500).json({ message: 'Database error', error: err });
        }

        if (results.length === 0) {
            return res.status(404).json({ message: 'User not found' });
        }

        const user = results[0];
        bcrypt.compare(password, user.password, (err, isMatch) => {
            if (err) {
                return res.status(500).json({ message: 'Error comparing passwords', error: err });
            }

            if (isMatch) {
                const token = jwt.sign({ userId: user.id, username: user.username }, JWT_SECRET, { expiresIn: '1h' });
                res.status(200).json({ message: 'Login successful', token: token });
            } else {
                res.status(401).json({ message: 'Invalid credentials' });
            }
        });
    });
});

// Middleware untuk verifikasi token
const verifyToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1]; // Bearer <token>

    if (token == null) {
        return res.sendStatus(401); // Unauthorized
    }

    jwt.verify(token, JWT_SECRET, (err, user) => {
        if (err) {
            return res.sendStatus(403); // Forbidden
        }
        req.user = user;
        next();
    });
};


// Endpoint untuk Reservasi (dilindungi)
app.post('/reservasi', verifyToken, (req, res) => {
    const { nama, email, telepon, tanggal, waktu, layanan } = req.body;
    const userId = req.user.userId;

    if (!nama || !email || !telepon || !tanggal || !waktu || !layanan) {
        return res.status(400).json({ message: 'All fields are required' });
    }

    const sql = 'INSERT INTO reservations (user_id, nama, email, telepon, tanggal, waktu, layanan) VALUES (?, ?, ?, ?, ?, ?, ?)';
    const values = [userId, nama, email, telepon, tanggal, waktu, layanan];

    db.query(sql, values, (err, result) => {
        if (err) {
            return res.status(500).json({ message: 'Database error on reservation', error: err });
        }
        res.status(201).json({ message: 'Reservation created successfully', reservationId: result.insertId });
    });
});


// Menjalankan server
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
