-- Hapus database lama jika ada, untuk memastikan kita memulai dari awal.
DROP DATABASE IF EXISTS `reservasi_db`;

-- Buat database baru dengan pengaturan karakter yang direkomendasikan.
CREATE DATABASE `reservasi_db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Pilih database yang baru dibuat agar semua perintah selanjutnya dijalankan di sana.
USE `reservasi_db`;

-- Buat tabel untuk data pengguna (users).
CREATE TABLE `users` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `username` VARCHAR(50) NOT NULL UNIQUE,
    `password` VARCHAR(255) NOT NULL
) ENGINE=InnoDB;

-- Buat tabel untuk data reservasi (reservations).
CREATE TABLE `reservations` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT,
    `nama` VARCHAR(100) NOT NULL,
    `email` VARCHAR(100) NOT NULL,
    `telepon` VARCHAR(20) NOT NULL,
    `tanggal` DATE NOT NULL,
    `waktu` TIME NOT NULL,
    `layanan` VARCHAR(100) NOT NULL,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;
